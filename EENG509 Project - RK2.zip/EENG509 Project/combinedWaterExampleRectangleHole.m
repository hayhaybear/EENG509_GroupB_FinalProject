clear; clc; close all;
dwtmode('sp0');

%% 1. Parameters & Setup
L_x = 2e6;        
L_y = 1e6; 
dx = 20000;
dy = 20000;
dt = 50;          
numSteps = 5000;
g = 9.81;         
f = 1e-4;         

% Wavelet Parameters
Nd = 3;     % Decompositions
iw = 1;     % Stencil width
th = 0.01;  % Threshold (Tuned for wavelet sensitivity)

% Grid (Must be power of 2 for Haar Wavelets)
% Let's force N to be 64x64 or 128x128 for the wavelet logic
nx_fixed = 128; 
ny_fixed = 128; 
x = linspace(-L_x/2, L_x/2, nx_fixed);
y = linspace(-L_y/2, L_y/2, ny_fixed);
[X, Y] = meshgrid(x,y);

% Initial condition: Rectangle
H = 100;
delta_h = 10;
h = ones(size(X)) * H;

% Set mins and maxes for the rectangle
xMin = -1000e3;
xMax = 1000e3;
yMin = -50e3;
yMax = 50e3;

% Create a mask and apply it
rectangleMask = (X >= xMin & X <= xMax) & (Y >= yMin & Y <= yMax); 
h(rectangleMask) = H - delta_h;
hu = zeros(size(h));
hv = zeros(size(h));

% Initial Mask Generation
[~, ~, gridMask] = newGrid2d_v3(x, h, th, Nd, iw);

% %% 2. Visualization Setup
% figure('Color', 'w', 'Position', [100 100 1000 400]);
% subplot(1,2,1);
% hPlot = surf(X/1e3, Y/1e3, h);
% shading interp; lighting gouraud; camlight;
% title('Wave Propagation');
% zlim([H-delta_h, H+delta_h]);
% 
% subplot(1,2,2);
% maskPlot = imagesc(x/1e3, y/1e3, gridMask);
% set(gca, 'YDir', 'normal');
% title('Active Wavelet Grid Mask');
% colormap(subplot(1,2,2), flipud(gray));
% 
% pause(15);


%% 3. Main Simulation Loop
tic;
for t = 1:numSteps
    
    % Update Wavelet Mask
    if mod(t, 100) == 0
        % Update mask based on current height field
        [~, ~, gridMask] = newGrid2d_v3(x, h, th, Nd, iw);
    end
    
    % RK2 (Heun's Method)
    [dh1, dhu1, dhv1] = compute_derivatives_masked(h, hu, hv, dx, dy, g, f, gridMask);
    
    % Predictor step
    h_tmp  = h  + dt * dh1;
    hu_tmp = hu + dt * dhu1;
    hv_tmp = hv + dt * dhv1;
    
    [dh2, dhu2, dhv2] = compute_derivatives_masked(h_tmp, hu_tmp, hv_tmp, dx, dy, g, f, gridMask);
    
    % Corrector step (Only update where gridMask == 1)
    h  = h  + 0.5 * dt * (dh1 + dh2);
    hu = hu + 0.5 * dt * (dhu1 + dhu2);
    hv = hv + 0.5 * dt * (dhv1 + dhv2);
    
    % Boundary Conditions
    h([1 end], :) = h([2 end-1], :);
    h(:, [1 end]) = h(:, [2 end-1]);
    hu(:, [1 end]) = 0; 
    hv([1 end], :) = 0;

    % %  Visualization 
    % if mod(t, 20) == 0
    %     set(hPlot, 'ZData', h);
    %     set(maskPlot, 'CData', gridMask);
    %     subplot(1,2,1); title(['Step: ', num2str(t)]);
    %     drawnow limitrate;
    % end
end
toc;

%% 4. Modified Functions
function [dh, dhu, dhv] = compute_derivatives_masked(h, hu, hv, dx, dy, g, f, mask)
    % Call the standard physics function
    [dh, dhu, dhv] = compute_derivatives(h, hu, hv, dx, dy, g, f);
    
    % MASKING: Apply the wavelet mask
    % We only allow changes to the state variables at 'active' points.
    % Boundary points should usually remain active to prevent artifacts.
    dh = dh .* mask;
    dhu = dhu .* mask;
    dhv = dhv .* mask;
end

function [dh, dhu, dhv] = compute_derivatives(h, hu, hv, dx, dy, g, f)
    [ny, nx] = size(h);
    dh = zeros(ny, nx); dhu = zeros(ny, nx); dhv = zeros(ny, nx);
    u = hu ./ max(h, 0.1);
    v = hv ./ max(h, 0.1);

    % X-Fluxes
    iL = 1:nx-1; iR = 2:nx;
    smax_x = max(abs(u(:,iL)) + sqrt(g*h(:,iL)), abs(u(:,iR)) + sqrt(g*h(:,iR)));
    Fh_x  = 0.5*(hu(:,iL) + hu(:,iR)) - 0.5*smax_x.*(h(:,iR) - h(:,iL));
    Fhu_x = 0.5*(hu(:,iL).*u(:,iL) + 0.5*g*h(:,iL).^2 + hu(:,iR).*u(:,iR) + 0.5*g*h(:,iR).^2) - 0.5*smax_x.*(hu(:,iR) - hu(:,iL));
    Fhv_x = 0.5*(hu(:,iL).*(hv(:,iL)./max(h(:,iL),0.1)) + hu(:,iR).*(hv(:,iR)./max(h(:,iR),0.1))) - 0.5*smax_x.*(hv(:,iR) - hv(:,iL));

    % Y-Fluxes
    jL = 1:ny-1; jR = 2:ny;
    smax_y = max(abs(v(jL,:)) + sqrt(g*h(jL,:)), abs(v(jR,:)) + sqrt(g*h(jR,:)));
    Gh_y  = 0.5*(hv(jL,:) + hv(jR,:)) - 0.5*smax_y.*(h(jR,:) - h(jL,:));
    Ghu_y = 0.5*(hv(jL,:).*(hu(jL,:)./max(h(jL,:),0.1)) + hv(jR,:).*(hu(jR,:)./max(h(jR,:),0.1))) - 0.5*smax_y.*(hu(jR,:) - hu(jL,:));
    Ghv_y = 0.5*(hv(jL,:).*v(jL,:) + 0.5*g*h(jL,:).^2 + hv(jR,:).*v(jR,:) + 0.5*g*h(jR,:).^2) - 0.5*smax_y.*(hv(jR,:) - hv(jL,:));

    dh(:, 2:end-1)  = -(Fh_x(:, 2:end) - Fh_x(:, 1:end-1))/dx;
    dhu(:, 2:end-1) = -(Fhu_x(:, 2:end) - Fhu_x(:, 1:end-1))/dx;
    dhv(:, 2:end-1) = -(Fhv_x(:, 2:end) - Fhv_x(:, 1:end-1))/dx;
    dh(2:end-1, :)  = dh(2:end-1, :)  - (Gh_y(2:end, :) - Gh_y(1:end-1, :))/dy;
    dhu(2:end-1, :) = dhu(2:end-1, :) - (Ghu_y(2:end, :) - Ghu_y(1:end-1, :))/dy;
    dhv(2:end-1, :) = dhv(2:end-1, :) - (Ghv_y(2:end, :) - Ghv_y(1:end-1, :))/dy;

    dhu = dhu + f * hv;
    dhv = dhv - f * hu;
end

function [xo, fo, gridMask] = newGrid2d_v3(xi, fi, th, Nd, iw)
    % newGrid2d_v2: Generates a logical mask for the FDM solver
    % xi: x-coordinates (vector)
    % fi: Current state (Height field h)
    % th: Threshold for wavelet coefficients
    % Nd: Number of decomposition levels
    % iw: Stencil width (radius of influence around active points)

    arguments (Input)
        xi, fi, th, Nd, iw
    end
    arguments (Output)
        xo, fo, gridMask
    end

    [nrows, ncols] = size(fi);
    gridMask = zeros(nrows, ncols);
    
    %  Step 1: Decomposition 
    % We store detail coefficients in a cell array for easier access
    H_details = cell(Nd, 1);
    V_details = cell(Nd, 1);
    D_details = cell(Nd, 1);
    
    current_data = fi;
    for idecomp = 1:Nd
        % Get levels using the corrected helper function
        [current_data, H1, V1, D1] = getApproxAndDetails(current_data, 'haar', idecomp, nrows);
        H_details{idecomp} = H1;
        V_details{idecomp} = V1;
        D_details{idecomp} = D1;
    end

    %  Step 2: Build the Mask 
    
    % Always keep the coarse background grid active (Every 2^Nd points)
    % This prevents the simulation from "dying" in flat areas.
    base_step = 2^Nd;
    gridMask(1:base_step:end, :) = 1;
    gridMask(:, 1:base_step:end) = 1;
    
    % Always keep boundaries active for the BC functions
    gridMask([1 end], :) = 1;
    gridMask(:, [1 end]) = 1;

    % Loop through each decomposition level to find sharp gradients (waves)
    for idecomp = 1:Nd
        step = 2^idecomp;
        % We only need to check the points that exist at this scale
        for r = 1:step:nrows
            for c = 1:step:ncols
                % Sum the absolute detail coefficients at this location
                coefSum = abs(H_details{idecomp}(r,c)) + ...
                          abs(V_details{idecomp}(r,c)) + ...
                          abs(D_details{idecomp}(r,c));
                
                % If the change is significant, activate the neighborhood
                if coefSum > th
                    r_start = max(1, r - iw);
                    r_end   = min(nrows, r + iw);
                    c_start = max(1, c - iw);
                    c_end   = min(ncols, c + iw);
                    
                    gridMask(r_start:r_end, c_start:c_end) = 1;
                end
            end
        end
    end
    
    % Grow the mask by 'iw' pixels in every direction
    % This ensures the stencil (neighbors) is always 'active'
    stencil = ones(2*iw + 1); 
    gridMask = imdilate(gridMask, stencil);

    % Outputs for compatibility with your existing script
    xo = xi; 
    fo = fi .* gridMask; 
end

function [A1,H1,V1,D1] = getApproxAndDetails(filterData,waveletFilter,decompNum,N)
    % Function calculates one level wavelet transform and returns approximation
    % (A1) and detail coefficients(H1,V1,D1)
    arguments (Input)
        filterData
        waveletFilter
        decompNum 
        N
    end
    arguments (Output)
        A1, H1,V1,D1
    end
    
    % Initialize full-size matrices
    H1 = zeros(N,N); V1 = zeros(N,N); D1 = zeros(N,N);
    
    % 1-level decomposition on the data passed in
    [c,s] = wavedec2(filterData, 1, waveletFilter);
    [h1,v1,d1] = detcoef2('all', c, s, 1);
    A1 = appcoef2(c, s, waveletFilter, 1);
    
    %  Fix: Dynamic Indexing 
    % Calculate the step size needed to distribute these coefficients 
    % across the original NxN grid.
    % Since we are at level 'decompNum', the spacing should be 2^decompNum.
    step = 2^decompNum;
    
    % Get sizes of the coefficient matrix
    [nh, nw] = size(h1);
    
    % Create indices that match the size of h1 but spaced by 'step'
    row_idx = 1:step:((nh-1)*step + 1);
    col_idx = 1:step:((nw-1)*step + 1);
    
    % Safeguard: Ensure indices do not exceed N due to rounding/padding in wavedec2
    row_idx = row_idx(row_idx <= N);
    col_idx = col_idx(col_idx <= N);
    
    % Assign the coefficients to the sparse grid locations
    H1(row_idx, col_idx) = h1(1:length(row_idx), 1:length(col_idx));
    V1(row_idx, col_idx) = v1(1:length(row_idx), 1:length(col_idx));
    D1(row_idx, col_idx) = d1(1:length(row_idx), 1:length(col_idx));
end
