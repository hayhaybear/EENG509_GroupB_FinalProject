function [xo, fo, gridMask] = newGrid2d_v2(xi, fi, th, Nd, iw)
    % newGrid2d_v2: Generates a logical mask for the FDM solver
    % xi: x-coordinates (vector)
    % fi: Current state (Height field h)
    % th: Threshold for wavelet coefficients
    % Nd: Number of decomposition levels
    % iw: Stencil width (radius of influence around active points)

    arguments (Input)
        xi, fi, th, Nd, iw
    end
    arguments (Output)
        xo, fo, gridMask
    end

    [nrows, ncols] = size(fi);
    gridMask = zeros(nrows, ncols);
    
    % --- Step 1: Decomposition ---
    % We store detail coefficients in a cell array for easier access
    H_details = cell(Nd, 1);
    V_details = cell(Nd, 1);
    D_details = cell(Nd, 1);
    
    current_data = fi;
    for idecomp = 1:Nd
        % Get levels using the corrected helper function
        [current_data, H1, V1, D1] = getApproxAndDetails(current_data, 'haar', idecomp, nrows);
        H_details{idecomp} = H1;
        V_details{idecomp} = V1;
        D_details{idecomp} = D1;
    end

    % --- Step 2: Build the Mask ---
    
    % Always keep the coarse background grid active (Every 2^Nd points)
    % This prevents the simulation from "dying" in flat areas.
    base_step = 2^Nd;
    gridMask(1:base_step:end, :) = 1;
    gridMask(:, 1:base_step:end) = 1;
    
    % Always keep boundaries active for the BC functions
    gridMask([1 end], :) = 1;
    gridMask(:, [1 end]) = 1;

    % Loop through each decomposition level to find sharp gradients (waves)
    for idecomp = 1:Nd
        step = 2^idecomp;
        % We only need to check the points that exist at this scale
        for r = 1:step:nrows
            for c = 1:step:ncols
                % Sum the absolute detail coefficients at this location
                coefSum = abs(H_details{idecomp}(r,c)) + ...
                          abs(V_details{idecomp}(r,c)) + ...
                          abs(D_details{idecomp}(r,c));
                
                % If the change is significant, activate the neighborhood
                if coefSum > th
                    r_start = max(1, r - iw);
                    r_end   = min(nrows, r + iw);
                    c_start = max(1, c - iw);
                    c_end   = min(ncols, c + iw);
                    
                    gridMask(r_start:r_end, c_start:c_end) = 1;
                end
            end
        end
    end
    
    % Outputs for compatibility with your existing script
    xo = xi; 
    fo = fi .* gridMask; 
end