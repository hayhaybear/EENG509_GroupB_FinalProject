function [A1,H1,V1,D1] = getApproxAndDetails(filterData,waveletFilter,decompNum,N)
% Function calculates one level wavelet transform and returns approximation
% (A1) and detail coefficients(H1,V1,D1)
arguments (Input)
    filterData
    waveletFilter
    decompNum 
    N
end
arguments (Output)
    A1, H1,V1,D1
end

% Initialize full-size matrices
H1 = zeros(N,N); V1 = zeros(N,N); D1 = zeros(N,N);

% 1-level decomposition on the data passed in
[c,s] = wavedec2(filterData, 1, waveletFilter);
[h1,v1,d1] = detcoef2('all', c, s, 1);
A1 = appcoef2(c, s, waveletFilter, 1);

% --- Fix: Dynamic Indexing ---
% Calculate the step size needed to distribute these coefficients 
% across the original NxN grid.
% Since we are at level 'decompNum', the spacing should be 2^decompNum.
step = 2^decompNum;

% Get sizes of the coefficient matrix
[nh, nw] = size(h1);

% Create indices that match the size of h1 but spaced by 'step'
row_idx = 1:step:((nh-1)*step + 1);
col_idx = 1:step:((nw-1)*step + 1);

% Safeguard: Ensure indices do not exceed N due to rounding/padding in wavedec2
row_idx = row_idx(row_idx <= N);
col_idx = col_idx(col_idx <= N);

% Assign the coefficients to the sparse grid locations
H1(row_idx, col_idx) = h1(1:length(row_idx), 1:length(col_idx));
V1(row_idx, col_idx) = v1(1:length(row_idx), 1:length(col_idx));
D1(row_idx, col_idx) = d1(1:length(row_idx), 1:length(col_idx));

end