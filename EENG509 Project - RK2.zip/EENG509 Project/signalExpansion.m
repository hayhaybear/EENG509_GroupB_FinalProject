clear; clc;

% Set Up
signal = [1 2 3;
          4 5 6];

num_coeff = 4;

%% Create the new signal and place the original signal in the center
new_signal = zeros( size(signal) + 2*(num_coeff - 1));

for i = 1:height(signal)
    for j = 1:length(signal)
        new_signal(num_coeff - 1 + i, num_coeff - 1 + j) = signal(i, j);
    end
end

% Copy indecies over to extend horizontally and vertically
first_col = signal(:, 1);
last_col = signal(:, length(signal));

first_row = signal(1, :);
last_row = signal(height(signal), :);

%% Extend the New Signal
% Dimension each stored vector to match the dimensions of the new signal
first_col = padarray(first_col, [(num_coeff-1) 0], 0, 'both');
last_col = padarray(last_col, [(num_coeff-1) 0], 0, 'both');

first_row = padarray(first_row, [0 (num_coeff-1)], 0, 'both');
last_row = padarray(last_row, [0 (num_coeff-1)], 0, 'both');

% Extend the signal horizontally
for i = 1:num_coeff-1
    new_signal(:, i) = first_col;
    new_signal(:, length(new_signal) - i + 1) = last_col;
end

% Extend the signal vertically
for i = 1:num_coeff-1
    new_signal(i, :) = first_row;
    new_signal(height(new_signal) - i + 1, :) = last_row;
end

%% Fill in the corners
% Find the correct values to place
top_left = ones(num_coeff - 1, num_coeff - 1) * signal(1, 1);
top_right = ones(num_coeff - 1, num_coeff - 1) * signal(1, length(signal));
bottom_left = ones(num_coeff - 1, num_coeff - 1) * signal(height(signal), 1);
bottom_right = ones(num_coeff - 1, num_coeff - 1) * signal(height(signal), length(signal));

% Place the Values
new_signal(1:(num_coeff-1), 1:(num_coeff-1)) = top_left;
new_signal(1:(num_coeff-1), (length(signal)+num_coeff):length(new_signal)) = top_right;
new_signal((height(signal)+num_coeff):height(new_signal), 1:(num_coeff-1)) = bottom_left;
new_signal((height(signal)+num_coeff):height(new_signal), (length(signal)+num_coeff):length(new_signal)) = bottom_right;
 