%% Test run

% Parameters Case One 
L_x = 20000000;
L_y = 8000000; 
dx = 156000;
dy = 95000; 
dt = 500; 
numSteps = 10000;
g_prime = 0.049;
beta = 2 * 10^-11;
lambda = 5 * 10^-4;
f = 7.2921*10^-5; 
l_x = 667000; 
l_y = 334000; 
H = 40;
delta_h = 60;

% Mesh Grid
x = -L_x/2:dx:L_x/2;
y = -L_y/2:dy:L_y/2;
[X, Y] = meshgrid(x,y);
length_x = length(x);
length_y = length(y); 

% Initial Conditions
u = zeros(size(X)); 
v = zeros(size(X)); 

h = H + delta_h*(exp(-((X.^2) / l_x^2) - (Y.^2) / l_y^2));

% Plot the intial h
figure;
surf(X,Y, h)
shading interp
title('Initial Condition Test')

% Try Finite Difference
for t = 1:numSteps
    hu = h.*u;
    hv = h.*v; 

    h_old = h; 
    u_old = u; 
    v_old = v; 

    hu_old = hu; 
    hv_old = hv;

    rightSide19 = (f.*h.*v) - (g_prime.*h.*SpatialX(h,dx, u)) + (lambda.*Laplacian(u.*h,dx,dy)) ...
                  -(SpatialX(u.*u.*h, dx, u)) - (SpatialY(u.*v.*h,dy, v)); 
    hu = hu_old + dt.*rightSide19;

    rightSide20 = -(f.*h.*u) - (g_prime.*h.*SpatialY(h,dy, v)) + (lambda.*Laplacian(v.*h,dx,dy))...
                  - (SpatialX((u.*v.*h), dx, u)) - (SpatialY((v.*v.*h),dy, v));
    hv = hv_old + dt.*rightSide20; 

    dhdt = -(SpatialX(hu_old, dx, u)) - (SpatialY(hv_old, dy, v));

    % Troubleshooting h
    minh = min(h(:));
    if minh < 1
        disp(['Warning: small h =', num2str(minh)]);
    end

    if any(h(:) < 0)
        disp('Negative height');
    end

    h = h_old + dt.*dhdt; 

    u = hu ./ h; 
    v = hv ./ h;

    % Boundary Conditions
    u(:, 1) = 0;  
    u(:, end) = 0;  
    h(:, 1) = h(:, 2);       
    h(:, end) = h(:, end-1);   
    v(:, 1) = v(:, 2);
    v(:, end) = v(:, end-1);

    v(1, :) = 0;  
    v(end, :) = 0;  
    h(1, :) = h(2, :);       
    h(end, :) = h(end-1, :);   
    u(1, :) = u(2, :);
    u(end, :) = u(end-1, :);

    if (mod(t,10) == 0)
        surf(X,Y, h);
        zlim([20 120]);
        pause(0.1); 
    end

end


% Second order derivative functions
% function dfdx = SpatialX(F, dx)
%     dfdx = zeros(size(F)); 
%     dfdx(:,2:end-1) = (F(:,3:end) - F(:,1:end-2)) / (2*dx);
% end

function dfdx = SpatialX(F, dx, u)
    dfdx = zeros(size(F));
    
    dfdx(:,2:end-1) = ...
        (u(:,2:end-1) > 0).* (F(:,2:end-1) - F(:,1:end-2))/dx + ...
        (u(:,2:end-1) <= 0).* (F(:,3:end) - F(:,2:end-1))/dx;
end

% function dfdy = SpatialY(F, dy)
%     dfdy = zeros(size(F)); 
%     dfdy(2:end-1,:) = (F(3:end,:) - F(1:end-2,:)) / (2*dy);
% end

function dfdy = SpatialY(F, dy, v)
    dfdy = zeros(size(F));
    
    dfdy(2:end-1,:) = ...
        (v(2:end-1,:) > 0).* (F(2:end-1,:) - F(1:end-2,:))/dy + ...
        (v(2:end-1,:) <= 0).* (F(3:end,:) - F(2:end-1,:))/dy;
end

function laplaceResult = Laplacian(F, dx, dy)
    xPart = zeros(size(F)); 
    yPart = zeros(size(F)); 

    xPart(:,2:end-1) = (F(:,3:end) - 2*F(:,2:end-1) + F(:,1:end-2)) / (dx^2);
    yPart(2:end-1,:) = (F(3:end,:) - 2*F(2:end-1,:) + F(1:end-2,:)) / (dy^2);

    laplaceResult = xPart + yPart;
end