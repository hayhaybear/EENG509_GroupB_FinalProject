clear; clc; close all;
% Parameters
L_x = 2e6;        % Reduced scale for better visibility
L_y = 1e6; 
dx = 20000;
dy = 20000;
dt = 50;          % Stability: dt < dx / sqrt(g*H)
numSteps = 5000;
g = 9.81;         % Real-world gravity
f = 1e-4;         % Coriolis parameter

% Grid
x = -L_x/2:dx:L_x/2;
y = -L_y/2:dy:L_y/2;
[X, Y] = meshgrid(x,y);

% Initial condition: Rectangle
H = 100;
delta_h = 10;
h = ones(size(X)) * H;

% Set mins and maxes for the rectangle
xMin = -1000e3;
xMax = 1000e3;
yMin = -50e3;
yMax = 50e3;

% Create a mask and apply it
rectangleMask = (X >= xMin & X <= xMax) & (Y >= yMin & Y <= yMax); 
h(rectangleMask) = H - delta_h;
hu = zeros(size(h));
hv = zeros(size(h));

% % Visualization setup
% figure('Color', 'w');
% hPlot = surf(X/1e3, Y/1e3, h);
% shading interp; lighting gouraud; camlight;
% xlabel('x (km)'); ylabel('y (km)'); zlabel('Height (m)');
% colorbar;
% zlim([H-delta_h, H+delta_h]);
% 
% % % Pause for the video
% pause(20);

% Pause to see IC
% pause(3);

% Start the Stopwatch
tic;

for t = 1:numSteps
    % --- RK2 (Heun's Method) ---
    [dh1, dhu1, dhv1] = compute_derivatives(h, hu, hv, dx, dy, g, f);
    
    % Predictor step
    h_tmp  = h  + dt * dh1;
    hu_tmp = hu + dt * dhu1;
    hv_tmp = hv + dt * dhv1;
    
    [dh2, dhu2, dhv2] = compute_derivatives(h_tmp, hu_tmp, hv_tmp, dx, dy, g, f);
    
    % Corrector step
    h  = h  + 0.5 * dt * (dh1 + dh2);
    hu = hu + 0.5 * dt * (dhu1 + dhu2);
    hv = hv + 0.5 * dt * (dhv1 + dhv2);
    
    % --- Boundary Conditions (Solid Walls) ---
    % Height: Zero gradient
    h([1 end], :) = h([2 end-1], :);
    h(:, [1 end]) = h(:, [2 end-1]);
    % Momentum: No flow through walls
    hu(:, [1 end]) = 0; 
    hv([1 end], :) = 0;

    % % Visualization
    % % Visualization inside the loop
    % if mod(t, 20) == 0
    %     set(hPlot, 'ZData', h);
    %     title(['Time Step: ', num2str(t)]);
    % 
    %     % Ensure both the Z-axis and the Colors stay put
    %     zlim([H-delta_h, H+delta_h]); 
    %     clim([95 101]); 
    % 
    %     drawnow limitrate;
    %     pause(0.025); 
    % end
end

toc;

function [dh, dhu, dhv] = compute_derivatives(h, hu, hv, dx, dy, g, f)
    [ny, nx] = size(h);
    dh = zeros(ny, nx); dhu = zeros(ny, nx); dhv = zeros(ny, nx);
    
    % Avoid division by zero
    u = hu ./ max(h, 0.1);
    v = hv ./ max(h, 0.1);

    % --- X-Direction Fluxes (Rusanov) ---
    iL = 1:nx-1; iR = 2:nx;
    hL = h(:,iL);   hR = h(:,iR);
    uL = u(:,iL);   uR = u(:,iR);
    huL = hu(:,iL); huR = hu(:,iR);
    hvL = hv(:,iL); hvR = hv(:,iR);
    
    smax_x = max(abs(uL) + sqrt(g*hL), abs(uR) + sqrt(g*hR));
    
    Fh_x  = 0.5*(huL + huR) - 0.5*smax_x.*(hR - hL);
    Fhu_x = 0.5*(huL.*uL + 0.5*g*hL.^2 + huR.*uR + 0.5*g*hR.^2) - 0.5*smax_x.*(huR - huL);
    Fhv_x = 0.5*(huL.*(hvL./max(hL,0.1)) + huR.*(hvR./max(hR,0.1))) - 0.5*smax_x.*(hvR - hvL);
    
    % --- Y-Direction Fluxes (Rusanov) ---
    jL = 1:ny-1; jR = 2:ny;
    hT = h(jL,:);   hB = h(jR,:);
    vT = v(jL,:);   vB = v(jR,:);
    huT = hu(jL,:); huB = hu(jR,:);
    hvT = hv(jL,:); hvB = hv(jR,:);
    
    smax_y = max(abs(vT) + sqrt(g*hT), abs(vB) + sqrt(g*hB));
    
    Gh_y  = 0.5*(hvT + hvB) - 0.5*smax_y.*(hB - hT);
    Ghu_y = 0.5*(hvT.*(huT./max(hT,0.1)) + hvB.*(huB./max(hB,0.1))) - 0.5*smax_y.*(huB - huT);
    Ghv_y = 0.5*(hvT.*vT + 0.5*g*hT.^2 + hvB.*vB + 0.5*g*hB.^2) - 0.5*smax_y.*(hvB - hvT);
    
    % --- Update Rates (Interior) ---
    dh(:, 2:end-1)  = -(Fh_x(:, 2:end) - Fh_x(:, 1:end-1))/dx;
    dhu(:, 2:end-1) = -(Fhu_x(:, 2:end) - Fhu_x(:, 1:end-1))/dx;
    dhv(:, 2:end-1) = -(Fhv_x(:, 2:end) - Fhv_x(:, 1:end-1))/dx;
    
    dh(2:end-1, :)  = dh(2:end-1, :)  - (Gh_y(2:end, :) - Gh_y(1:end-1, :))/dy;
    dhu(2:end-1, :) = dhu(2:end-1, :) - (Ghu_y(2:end, :) - Ghu_y(1:end-1, :))/dy;
    dhv(2:end-1, :) = dhv(2:end-1, :) - (Ghv_y(2:end, :) - Ghv_y(1:end-1, :))/dy;
    
    % --- Coriolis Force (Applied to momentum rates) ---
    dhu = dhu + f * hv;
    dhv = dhv - f * hu;
end
